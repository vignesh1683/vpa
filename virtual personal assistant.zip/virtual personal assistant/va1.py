import sys
import speech_recognition as sr
import pyttsx3
import datetime
import wikipedia
import webbrowser
import pywhatkit
import pyjokes
import os
import wolframalpha
import tkinter as tk
from tkinter import scrolledtext
import threading
from ttkthemes import themed_tk
from PIL import ImageTk,Image
import tkinter.scrolledtext as scrolledtext
import pyaudio
import time
from ecapture import ecapture as ec
# Initialize text to speech engine
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)
engine.setProperty('rate',150)

try:
    app=wolframalpha.Client("4WPLGV-TGLQ3PAV8H")  #API key for wolframalpha
except Exception as e:
    pass

def CommandsList():
    '''show the command to which voice assistant is registered with'''
    os.startfile('Commands List.txt')

def there_exists(terms,query):
    for term in terms:
        if term in query:
            return True

# Speak function to output audio
def speak(audio):
    engine.say(audio)
    engine.runAndWait()
# Function to greet the user
def greet():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Good morning!")
    elif hour >= 12 and hour < 18:
        speak("Good afternoon!")
    elif hour >= 18 and hour < 21:
        speak("Good evening!")
    else:
        speak("Good night!")
    speak("I'm your virtual personal assistant.... how can i help you??")
# Function to take user input and return text
def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        speak("listening")
        print("Listening...")
        r.adjust_for_ambient_noise(source, duration=1)
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        speak("Recognizing")
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")
    except Exception as e:
        speak("please say that again")
        print("Say that again please...")
        return "None"
    return query




def mainframe():
    """Logic for execution task based on query"""
    greet()
    query_for_future = None
    while True:
        query = takeCommand().lower()

        # wikipedia search
        if there_exists(['search wikipedia for', 'from wikipedia'], query):
            print("Searching wikipedia...")
            speak("Searching wikipedia...")
            if 'search wikipedia for' in query:
                query = query.replace('search wikipedia for', '')
                results = wikipedia.summary(query, sentences=2)
                speak("According to wikipedia:\n")
                speak(results)
            elif 'from wikipedia' in query:
                query = query.replace('from wikipedia', '')
                results = wikipedia.summary(query, sentences=2)
                speak("According to wikipedia:\n")
                speak(results)
        elif there_exists(['wikipedia'], query):
            print("Searching wikipedia...")
            speak("Searching wikipedia....")
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("According to wikipedia:\n")
            speak(results)
        elif 'who is' in query:
            print("Searching wikipedia...")
            speak('Searching Wikipedia...')
            query = query.replace('who is', "")
            results = wikipedia.summary(query, sentences=2)
            speak("According to Wikipedia")
            speak(results)

        elif 'play' in query:
               song = query.replace('play', '')
               speak('playing ' + song)
               pywhatkit.playonyt(song)



       # time and date
        elif there_exists(['the time','time'], query):
           strTime = datetime.datetime.now().strftime("%H:%M:%S")
           speak(f"The time is {strTime}")
        elif there_exists(['the date','date'], query):
            strDate = datetime.date.today().strftime("%B %d, %Y")
            speak(f"Today is {strDate}")
        elif there_exists(['what day it is', 'what day is today', 'which day is today', "today's day name please","today's day"],
                          query):
            speak(f"Today is {datetime.datetime.now().strftime('%A')}")

        # jokes
        elif there_exists(['tell me joke', 'tell me a joke', 'tell me some jokes', 'i would like to hear some jokes',
             "i'd like to hear some jokes",
             'can you please tell me some jokes', 'i want to hear a joke', 'i want to hear some jokes',
             'please tell me some jokes',
             'would like to hear some jokes', 'tell me more jokes'], query):
            speak(pyjokes.get_joke(language="en", category="all"))
            query_for_future = query
        elif there_exists(
                ['one more', 'one more please', 'tell me more', 'i would like to hear more of them', 'once more',
                 'once again', 'more', 'again'], query) and (query_for_future is not None):
            speak(pyjokes.get_joke(language="en", category="all"))

        # google, youtube and location
        # playing on youtube
        elif there_exists(['open youtube and play', 'on youtube'], query):
            if 'on youtube' in query:
                speak("Opening youtube")
                pywhatkit.playonyt(query.replace('on youtube', ''))
            else:
                speak("Opening youtube")
                pywhatkit.playonyt(query.replace('open youtube and play ', ''))
            break

        elif there_exists(
                ['play some songs on youtube', 'i would like to listen some music', 'i would like to listen some songs',
                 'play songs on youtube'], query):
            speak("Opening youtube")
            pywhatkit.playonyt('play random songs')
            break

        elif there_exists(['open youtube', 'access youtube'], query):
            speak("Opening youtube")
            webbrowser.open("youtube.com")
            break

        elif there_exists(['open google and search', 'google and search'], query):
            url = 'https://google.com/search?q=' + query[query.find('for') + 4:]
            webbrowser.open(url)
            break

        # image search
        elif there_exists(['show me images of', 'images of', 'display images'], query):
            url = "https://www.google.com/search?tbm=isch&q=" + query[query.find('of') + 3:]
            webbrowser.open(url)
            break



        elif there_exists(['search for', 'do a little searching for', 'show me results for', 'show me result for',
                           'start searching for'], query):
            speak("Searching.....")
            if 'search for' in query:
                speak(f"Showing results for {query.replace('search for', '')}")
                pywhatkit.search(query.replace('search for', ''))
            elif 'do a little searching for' in query:
                speak(f"Showing results for {query.replace('do a little searching for', '')}")
                pywhatkit.search(query.replace('do a little searching for', ''))
            elif 'show me results for' in query:
                speak(f"Showing results for {query.replace('show me results for', '')}")
                pywhatkit.search(query.replace('show me results for', ''))
            elif 'start searching for' in query:
                speak(f"Showing results for {query.replace('start searching for', '')}")
                pywhatkit.search(query.replace('start searching for', ''))
            break

        elif there_exists(['open google'], query):
            speak("Opening google")
            webbrowser.open("https://www.google.com")
            break

        elif there_exists(['find location of', 'show location of', 'find location for', 'show location for'], query):
            if 'of' in query:
                url = 'https://google.nl/maps/place/' + query[query.find('of') + 3:] + '/&amp'
                webbrowser.open(url)
                break
            elif 'for' in query:
                url = 'https://google.nl/maps/place/' + query[query.find('for') + 4:] + '/&amp'
                webbrowser.open(url)
                break

        elif there_exists(
                ["what is my exact location", "What is my location", "my current location", "exact current location"],
                query):
            url = "https://www.google.com/maps/search/Where+am+I+?/"
            webbrowser.get().open(url)
            speak("Showing your current location on google maps...")

        # opening software applications
        elif there_exists(['open chrome','open browser'], query):
            speak("Opening chrome")
            os.startfile(r'C:\Program Files\Google\Chrome\Application\chrome.exe')
            break
        elif there_exists(['open notepad', 'start notepad','notepad'], query):
            speak('Opening notepad')
            os.startfile(r'C:\Windows\notepad.exe')
            break
        elif there_exists(['open snipping tool', 'snipping tool', 'start snipping tool'], query):
            speak("Opening snipping tool....")
            os.startfile(r"C:\Users\vigne\AppData\Local\Microsoft\WindowsApps\Microsoft.ScreenSketch_8wekyb3d8bbwe\SnippingTool.exe")
            break
        elif there_exists(['open zoom', 'open meeting ', 'open zoom meeting'], query):
            speak("Opeining zoom meeting")
            codepath = r"C:\Users\vigne\AppData\Roaming\Zoom\zoom_install_src\Zoom.exe"
            os.startfile(codepath)
            break
        elif there_exists(['open code', 'open pycharm ', 'open pycharm code'], query):
            speak("Opeining pycharm")
            codepath = r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\JetBrains\PyCharm Community Edition 2023.1.1.lnk"
            os.startfile(codepath)
            break
        elif there_exists(['open file manager', 'file manager', 'open my computer', 'my computer', 'open file explorer',
                           'file explorer', 'open this pc', 'this pc'], query):
            speak("Opening File Explorer")
            os.startfile("C:\Windows\explorer.exe")
            break
        elif there_exists(['cmd', 'command prompt', 'command prom', 'commandpromt', 'command'], query):
            speak("Opening command prompt")
            os.startfile(r"C:\Windows\SysWOW64\cmd.exe")
            break
        elif there_exists(['open telegram','telegram'], query):
            speak("Opening telegram")
            os.startfile(r"C:\Users\vigne\AppData\Roaming\Telegram Desktop\Telegram.exe")
            break

        # shutting down system
        elif there_exists(['exit', 'quit', 'shutdown', 'shut up', 'goodbye', 'shut down'], query):
            speak("shutting down")
            sys.exit()

        elif there_exists(['none'], query):
            pass
        elif there_exists(['stop the flow', 'stop the execution', 'halt', 'halt the process', 'stop the process',
                           'stop listening', 'stop the listening'], query):
            speak("Listening halted.")
            break

        elif there_exists(['write a note', 'take notes', 'take a note'], query):
            speak("What should i write?")
            note = takeCommand()
            file = open('note.txt', 'w')
            speak("Should i include date and time in notes")
            snfm = takeCommand()
            if 'yes' in snfm or 'sure' in snfm:
                strTime = datetime.datetime.now().strftime("%H:%M:%S ")
                file.write(strTime)
                strDay = datetime.date.today().strftime("%B %d, %Y")
                file.write(strDay)
                file.write(" :- ")
                file.write(note)
            else:
                file.write(note)

        elif "show notes" in query:
            speak("Showing Notes")
            file = open("note.txt", "r")
            print(file.read())
            speak(file.read(6))

        elif "don't listen" in query or "stop listening" in query:
            speak("how much seconds you want to stop from listening commands...say only the number of seconds")
            a = int(takeCommand())
            time.sleep(a)
            print(a)



        elif "camera" in query or "take a photo" in query:
            ec.capture(0, "VPA's camera ", "img.jpg")


        # it will give online results for the query
        elif there_exists(
            ['search something for me', 'to do a little search', 'search mode', 'i want to search something'],
            query):
            speak('What you want me to search for?')
            query = takeCommand()
            speak(f"Showing results for {query}")
            try:
                res = app.query(query)
                speak(next(res.results).text)
            except:
                print("Sorry, but there is a little problem while fetching the result.")

        # what is the capital
        elif there_exists(['what is the capital of', 'capital of', 'capital city of'], query):
            try:
                res = app.query(query)
                speak(next(res.results).text)
            except:
                print("Sorry, but there is a little problem while fetching the result.")

        elif there_exists(['temperature'], query):
            try:
                res = app.query(query)
                speak(next(res.results).text)
            except:
                print("Internet Connection Error")
        elif there_exists([

        ], query):
            try:
                res = app.query(query)
                speak(next(res.results).text)
            except:
                print("Internet Connection Error")

        else:
            speak("Sorry it did not match with any commands that i'm registered with. Please say it again.")

def gen(n):
    for i in range(n):
        yield i

class MainframeThread(threading.Thread):
    def __init__(self, threadID, name):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
    def run(self):
        mainframe()

def Launching_thread():
    Thread_ID=gen(1000)
    global MainframeThread_object
    MainframeThread_object=MainframeThread(Thread_ID.__next__(),"Mainframe")
    MainframeThread_object.start()

if __name__=="__main__":
        #tkinter code
        root=themed_tk.ThemedTk()
        root.set_theme("winnative")
        root.geometry("{}x{}+{}+{}".format(745,360,int(root.winfo_screenwidth()/2 - 745/2),int(root.winfo_screenheight()/2 - 360/2)))
        root.resizable(0,0)
        root.title("Virtual Personal Assistant")
        root.configure(bg='#2c4557')
        scrollable_text=scrolledtext.ScrolledText(root,state='disabled',height=15,width=87,relief='sunken',bd=5,wrap=tk.WORD,
                                                  bg='#add8e6',fg='#800000')
        scrollable_text.place(x=10,y=10)
        mic_img=Image.open("Mic.png")
        mic_img=mic_img.resize((55,55),Image.ANTIALIAS)
        mic_img=ImageTk.PhotoImage(mic_img)
        Speak_label=tk.Label(root,text="SPEAK:",fg="#FFD700",font='"Times New Roman" 12 ',borderwidth=0,bg='#2c4557')
        Speak_label.place(x=250,y=300)
        s234 = tk.Label(root, text="Hey! I'm your virtual personal assistant", fg="#FFD700", font='"Times New Roman" 12 ', borderwidth=0,
                               bg='#2c4557')
        s234.place(x=200, y=130)
        s234 = tk.Label(root, text="Hey! I'm your virtual personal assistant....Press the mic icon to start", fg="#FFD700",
                        font='"Times New Roman" 12 ', borderwidth=0,
                        bg='#2c4557')
        s234.place(x=150, y=130)
        """Setting up objects"""
        Listen_Button = tk.Button(root,image=mic_img,borderwidth=0,activebackground='#2c4557',bg='#2c4557',command=Launching_thread)
        Listen_Button.place(x=330,y=280)
        myMenu=tk.Menu(root)
        m1=tk.Menu(myMenu,tearoff=0) #tearoff=0 means the submenu can't be teared of from the window
        m1.add_command(label='Commands List',command=CommandsList)
        myMenu.add_cascade(label="Help",menu=m1)
        root.config(menu=myMenu)
        root.mainloop()